module.exports = {
  User: require("./user"),
  Event: require("./event"),
  Log: require("./log"),
};
