import React from "react";
import ReactDOM from "react-dom";
import '../src/components/pages/FAQ/faq.css'

import Root from "./Root";

ReactDOM.render(<Root />, document.getElementById("root"));
