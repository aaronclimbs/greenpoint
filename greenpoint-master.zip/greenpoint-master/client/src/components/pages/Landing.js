import React, { Component } from "react";


export default class Landing extends Component {
  render() {
    return (
      <div>
        <h5 className="text-center mt-2 mb-2">Learn how your daily actions impact your carbon footprint</h5>
      </div>
    );
  }
}
