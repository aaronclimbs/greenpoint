import React, { Component } from "react";
import "./Resources.css"

export default class Resources extends Component {
  render() {
    return (
      <div>
        <h5 className="text-center mt-2 mb-2">Resources</h5>
      </div>
    );
  }
}
