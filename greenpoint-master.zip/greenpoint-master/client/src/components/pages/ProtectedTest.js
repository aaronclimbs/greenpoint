import React, { Component } from "react";

export default class ProtectedTest extends Component {
  render() {
    return (
      <div>
        <h1>This route is protected.</h1>
      </div>
    );
  }
}
