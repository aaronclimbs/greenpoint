const qsAndAs = {

    question1: {
        question: "What is Greenpoint?",
        answer: "Lorem ipsum dolor amet direct trade lo-fi sriracha street art farm-to-table mumblecore quinoa keytar typewriter adipisicing hammock venmo hella. Sartorial marfa vinyl salvia. Scenester truffaut pinterest, four loko ugh schlitz intelligentsia vinyl. Dolor typewriter paleo la croix chartreuse meditation before they sold out ethical unicorn mustache helvetica +1 next level pinterest. Next level reprehenderit af asymmetrical, sunt id sartorial woke."
    }, 

    question2: {
        question: "How do I get points?",
        answer: "Pabst yr swag, woke blog dolore officia aesthetic. Brunch artisan dolore meggings selvage tbh selfies id. Ut cold-pressed pariatur art party fanny pack salvia. Proident tbh tousled fugiat sunt. Hell of waistcoat cloud bread poke taiyaki trust fund."
    }, 

    question3: {
        question: "What if my event isn't listed?",
        answer: "Poke vegan mumblecore iceland, enamel pin vaporware williamsburg letterpress fugiat banjo. Seitan wolf succulents pop-up, raclette cliche VHS mumblecore. Raw denim thundercats pariatur irony aliqua ethical activated charcoal dreamcatcher health goth seitan umami shabby chic next level. Aute hashtag aliquip yr. Mustache typewriter laborum farm-to-table street art veniam man braid YOLO ethical lyft single-origin coffee. Consequat kale chips semiotics, et est quis elit."
    }, 

    question4: {
        question: "What badges can I get?",
        answer: "Proident hashtag authentic jianbing, umami qui lomo literally dolore XOXO anim tbh chillwave ullamco franzen. Jianbing air plant selvage pop-up fanny pack magna microdosing meditation. Marfa semiotics microdosing fixie, excepteur veniam church-key ut. Chillwave hell of proident fam coloring book williamsburg selvage vexillologist hashtag etsy. Velit live-edge ullamco, godard man bun plaid tattooed. Live-edge skateboard reprehenderit kombucha adaptogen intelligentsia post-ironic."
    }, 

    question5: {
        question: "Why are you doing this?",
        answer: "Plaid flexitarian shoreditch, flannel elit mixtape trust fund single-origin coffee reprehenderit meh tbh cronut magna disrupt. Hammock seitan hexagon magna irony dolore aesthetic. Glossier distillery af microdosing, hell of tempor in reprehenderit chambray tilde kale chips portland palo santo lorem. Godard swag vape tattooed fashion axe. Taiyaki tumblr est ennui, kitsch fugiat tote bag chicharrones iPhone polaroid meditation franzen quinoa in. Normcore lyft tumeric, 8-bit wayfarers echo park knausgaard typewriter."
    }

}

export default qsAndAs;